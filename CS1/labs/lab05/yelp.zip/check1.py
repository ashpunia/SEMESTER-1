# -*- coding: utf-8 -*-
"""
Created on Tue Oct 11 15:01:00 2022

@author: puniaa
"""

import lab05_util
restaurants = lab05_util.read_yelp('yelp.txt')